let config = {
    host    : 'localhost',
    user    : 'root',
    password: 'root1234',
    database: 'mood_me'
  };
  
  module.exports = config;