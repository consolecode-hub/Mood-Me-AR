
var express = require("express");
var multer = require('multer');
var app = express();

let mysql  = require('mysql2');
let config = require('./config.js');
let connection = mysql.createConnection(config);



var storage = multer.diskStorage({
  destination: function (req, file, callback) {
    callback(null, './uploads');
  },
  filename: function (req, file, callback) {
    callback(null, file.originalname);
  }
});
var upload = multer({ storage: storage }).single('file');
 
app.get('/', function (req, res) {
  res.sendFile(__dirname + "/index.html");
});
 
app.post('/upload', function (req, res) {




  upload(req, res, function (err) {
    if (err) {
      return res.end("Error uploading file.");
    }
    

    var name = req.body.name;
    var extension = req.body.extension;
    var imei = req.body.imei;


    connection.query(
      `SELECT * FROM mood_table WHERE file_name = ? `, [name],
      function (err, res) {
          if (err) {
              console.error("An error occurred:", err.message);
             // responce.status(500).json({ status: 500, message: "An error occurred: " + err.message });
          } else {
              if (res.length) {
                  console.log( "file found successfully.");
                //  responce.status(200).json({ status: 200, message: "file found." });
              } else {
               // insert statment
                  var query = `
                  INSERT INTO mood_table 
                  (ip, file_name, type) 
                  VALUES ("${imei}", "${name}", "${extension}")
                  `;

                  // execute the insert statment
                  connection.query(query, function(error, data){

                  if(error)
                  {
                    throw error;
                  }	
                  else
                  {
                    console.log( "Uploaded successfully.");


                  }

                  });

                
              }
          }
      }
  )


  });




});
  




app.listen(3000, function () {
  console.log("Working on port 3000");
});